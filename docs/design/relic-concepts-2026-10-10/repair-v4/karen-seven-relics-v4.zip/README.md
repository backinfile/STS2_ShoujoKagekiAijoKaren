# Karen 七件新增遗物 · 修复 V4

final/ 含七张1254×1254透明PNG。native/ 含本轮四张的原生裁切版；发饰336×384、王冠388×223，画布版仅常规插值。

棒球猫与水壶使用内置image_gen参考补绘＋本地Artifact Cleaner 0.25；发饰与王冠直接保留原照片／截图像素抠图。饼干、金色四角星、Mr. White保留已清理稿。饼干小字细节属于推补。

怀表牌与三张错误旧稿均未包含。华恋的水壶等新增名称仍为候选，七件效果未改变。来源、效果及处理方式见items.json，生成提示词见prompts.json，最终校验见manifest.json。

- 华恋的水壶：https://minkara.carview.co.jp/userid/968130/blog/41815373/
- 棒球猫：https://prtimes.jp/main/html/rd/p/000006806.000014827.html
- 星形发饰：https://www.geestore.com/detail/id/00000090566
- 星之王冠：https://anime-tip.com/sahplant/revuestarlight/9060